# 关系教练 · Relationship Coach （GitHub Pages 版）

这是一个高杀伤优雅反击教学工具（纯前端单页）。包含：时间轴、10 条速查卡片、万能回击生成器、参考资料、夜间模式、可折叠目录。

## 在线访问
部署完成后，你的站点会在：  
`https://<你的GitHub用户名>.github.io/<仓库名>/`

> 若仓库名为 `<你的GitHub用户名>.github.io`，则访问根域名：  
> `https://<你的GitHub用户名>.github.io`

## 快速开始
1. 打开本仓库 → **Settings → Pages**
2. **Source** 选择 `main` 分支，**Branch** 选择 `/root`
3. 点击 **Save**，等待 1–3 分钟，刷新生成的链接即可访问

## 本地预览
直接双击 `index.html` 即可在浏览器打开，无需环境。

## 结构
```
index.html     # 网页主体（精修版）
README.md      # 项目说明（本文件）
LICENSE        # 协议（MIT）
.nojekyll      # 禁用 Jekyll 处理
```

## 自定义
- 配色：在 `index.html` 中搜索 `:root` 和 `body.dark`，修改 CSS 变量即可
- 文案：在文件底部 `<script>` 的 `quickList` 常量中维护 10 条卡片
- 生成器：同一处脚本，表单字段可按需增删

## License
本项目采用 MIT 协议。详见 [LICENSE](LICENSE) 文件。
